<?php
    include "config.php";
    $username = $_SESSION['username'];
    $fname = $_POST['fname'];
    $fprice = $_POST['fprice'];
    $productid = $_POST['productid'];
    $cart = $_POST['cart'];
    $delete = $_POST['del'];
    $order = $_POST['order'];


    if (isset($cart)) { 
        $result_username = mysqli_query($con,"select * from food where id = '$productid'") or die("failed to query database");
        $row_username = mysqli_fetch_array($result_username);
        if($row_username['id'] !== $productid) { 
            mysqli_query($con,"update food set cart = 'Y' where id= '$productid'") or die("failed to query database");
            echo '<script type ="text/javascript"> alert("Added to cart");window.history.go(-1);</script>';
            die();
        }
            mysqli_query($con,"update food set cart = 'Y' where id= '$productid'") or die("failed to query database");
            echo '<script type ="text/javascript"> alert("Added to cart");window.history.go(-1);</script>';

    die();

    }else if (isset($delete)) { 
        mysqli_query($con,"update food set cart = 'N' where id= '$productid'") or die("failed to query database");
        echo '<script type ="text/javascript"> alert("Product Successfully Removed.");window.history.go(-1);</script>';
    }else if (isset($order)) { 
        echo '<script type ="text/javascript"> alert("Ordered Successfully.");window.history.go(-1);</script>';
    }else {	
        header('location: login.html');
    }
