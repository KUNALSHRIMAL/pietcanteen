<?php
require('stripe-php-master/init.php');

$publishableKey="pk_test_51MmUxMSF9NvUmuRIpFTMtMw49ZSc7XcdtMeTNhwA1j5X7PpJe4uVMLTQBMCWNFEYQz5UZIezVr6fSoMbI6lW1JEo00HYtIjv7y";

$secretKey="sk_test_51MmUxMSF9NvUmuRIQ4QpGfyREb1r16f5rmQk8fMfuSjsbeuxrlT54hCma0C5IwTEsOMFq2YT2lNA9TTUR9gmnlAP008JeVFyUT";

\Stripe\Stripe::setApiKey($secretKey);
?>