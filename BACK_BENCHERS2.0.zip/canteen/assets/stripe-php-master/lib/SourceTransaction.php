<?php

namespace Stripe;

/**
 * Class SourceTransaction
 *
 * @package Stripe
 */
class SourceTransaction extends ApiResource
{

}
