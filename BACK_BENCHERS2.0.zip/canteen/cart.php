<?php
include 'config.php';
session_start();
if (isset($_SESSION['username']))
  echo '';
else
  header('location:login.html');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>welcome</title>
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Favicons
    ================================================== -->
  <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" href="assets/img/apple-touch-icon.png">
  <link rel="apple-touch-icon" sizes="72x72" href="assets/img/apple-touch-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="114x114" href="assets/img/apple-touch-icon-114x114.png">

  <!-- Bootstrap -->
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="assets/fonts/font-awesome/css/font-awesome.css">

  <!-- Stylesheet
    ================================================== -->
  <link rel="stylesheet" type="text/css" href="assets/css/style.css">
  <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Rochester" rel="stylesheet">

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
  <!-- Navigation
    ==========================================-->
  <nav id="menu" class="navbar navbar-default navbar-fixed-top">
    <div class="container">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li><a href="home.php#" class="page-scroll">Home</a></li>
          <li><a href="home.php#restaurant-menu" class="page-scroll">Menu</a></li>
          <li><a href="#" class="page-scroll">Cart</a></li>
          <li><a href="logout.php" rel="html">logout</a> </a></li>
        </ul>
      </div>
      <!-- /.navbar-collapse -->
    </div>
  </nav>
  <!-- Header -->
  <header id="header">
    <div class="intro">
      <div class="overlay">
        <div class="container">
          <div class="row">
            <div class="intro-text">
              <h1>My Cart</h1>
              <p>Welcome To My Restaurant</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- Restaurant Menu Section -->
  <div id="restaurant-menu">
    <div class="container">
      <div class="section-title text-center">
        <h2>Your Items</h2>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="menu-section">
            <?php
            $results = mysqli_query($con, "SELECT * FROM food WHERE cart='Y' ORDER BY id DESC") or die("failed to query database");
            // $rows = mysqli_fetch_array($results);
            if ($results->num_rows > 0) {
              while ($rows = $results->fetch_assoc()) {
                $fname = $rows["fname"];
                $fprice = $rows["fprice"];
                $productid = $rows['id'];
            ?>
                <form id="cart" class="validate-form" action="bcart.php" method="post" enctype="multipart/form-data">
                  <ul class="featured__item__pic__hover">
                    <input type="hidden" name="productid" value="<?php echo $productid;
                                                                  $_SESSION['id'] = $productid; ?>">
                    <div class="menu-item">
                      <div class="menu-item-name"><input type="hidden" name="fname" value="<?php echo $fname; ?> ">
                        <?php echo $fname; ?>
                      </div>
                      <div class="menu-item-price"><input type="hidden" name="fprice" value="<?php echo $fprice; ?>"> <?php echo $fprice; ?>/- <button type="submit" class="btn btn-danger" name="del">Remove</button></div>
                    </div>
                </form>
              <?php }
            } else { ?>
              <p style="margin-top: 8%"><i class="fa fa-error"></i> YOUR CART IS EMPTY</p>
            <?php } ?>
          </div>
        </div>
      </div>






      <div class="row">
        <div class="col-12">
          <div class="menu-section">
            <?php
               $results = mysqli_query($con, "SELECT SUM(fprice) AS 'Total cart' FROM food WHERE cart='Y'") or die("failed to query database");
               $rows = mysqli_fetch_array($results);
               $total= $rows['Total cart'];
            if ($total> 0) { 
            ?>
                <form id="cart" class="validate-form" action="assets/index.php" method="post" enctype="multipart/form-data">
                  <ul class="featured__item__pic__hover">
                    <div class="menu-item">
                      <div class="menu-item-name">Total 
                      </div>
                      <div class="menu-item-price"><input type="hidden" name="fprice" value="<?php echo $total; ?>"> <?php echo $total; ?>/- <button type="submit" class="btn btn-success" name="order">Order Now</button></div>
                    </div>
                </form>
              <?php 
            } else { ?>
              <p style="margin-top: 8%"><i class="fa fa-error"></i> YOUR CART IS EMPTY</p>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="footer">
    <div class="container text-center">
      <div class="col-md-6">
        <p>&copy; All rights reserved. Design by <a href="#" rel="nofollow">Back Banchers 2.0</a></p>
      </div>
      <div class="col-md-6">
        <div class="social">
          <ul>
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <script type="text/javascript" src="assets/js/jquery.1.11.1.js"></script>
  <script type="text/javascript" src="assets/js/bootstrap.js"></script>
  <script type="text/javascript" src="assets/js/SmoothScroll.js"></script>
  <script type="text/javascript" src="assets/js/jqBootstrapValidation.js"></script>
  <script type="text/javascript" src="assets/js/contact_me.js"></script>
  <script type="text/javascript" src="assets/js/main.js"></script>
</body>

</html>