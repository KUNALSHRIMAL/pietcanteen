  <?php
  session_start();
  include 'config.php';


  // if (isset($_SESSION[$username])){
  // 	echo ''; }
  // else{
  //   header('location:../login.html');
  // }
  $sql = "SELECT * FROM food";

  $result = $con->query($sql);
  if (isset($_SESSION['username']))
    $username=$_SESSION['username'];
  else
    header('location:../login.html');


  ?>
<!DOCTYPE html>

<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>College Canteen Admin Panel</title>

	<link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
    
    <link rel="shortcut icon" href="../assets/img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="../assets/img/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="72x72" href="../assets/img/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="../assets/img/apple-touch-icon-114x114.png">

    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../assets/fonts/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/login-animate.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/login-style.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/login.css">

    <!-- Stylesheet
    ================================================== -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- <link href="https://fonts.googleapis.com/css?family=Rochester" rel="stylesheet"> -->
</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
  <!-- Navigation
    ==========================================-->
  <nav id="menu" class="navbar navbar-default navbar-fixed-top">
    <div class="container">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li><a href="index.php" class="page-scroll">Home</a></li>
          <li><a href="logout.php" rel="html">logout</a> </a></li>
        </ul>
      </div>
      <!-- /.navbar-collapse -->
    </div>
  </nav>
  <!-- Header -->
  <header id="header">
    <div class="intro">
      <div class="overlay">
        <div class="container">
          <div class="row">
            <div class="intro-text">
              <h1 >Welcome, <?php echo $username;?></h1>
              <p>You can manage the college canteen from this panel.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
    <!-- HTML for image slideshow 
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
		<div class="carousel-inner">
		  <div class="carousel-item active">
			<img class="d-block w-100" src="..." alt="First slide">
		  </div>
		  <div class="carousel-item">
			<img class="d-block w-100" src="..." alt="Second slide">
		  </div>
		  <div class="carousel-item">
			<img class="d-block w-100" src="..." alt="Third slide">
		  </div>
		</div>
		<a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
		  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
		  <span class="sr-only">Previous</span>
		</a>
		<a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
		  <span class="carousel-control-next-icon" aria-hidden="true"></span>
		  <span class="sr-only">Next</span>
		</a>
	  </div>-->

  
	<main>
		<!-- <section id="1">
			<h2>Welcome, <?php echo $username;?></h2>
			<p>You can manage the college canteen from this panel.</p>
		</section> -->

		<div id="menu"></div>
		<section>
			<h2>Menu Management</h2>
      <table>
    <tr style="background-color: black; color: white;">
        <th>ID</th>
        <th>Food_Name</th>
        <th>Food_prize</th>
        <th>Food_Category</th>
    </tr>
    <?php
    // Loop through the result and output each row as a table row
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["id"] . "</td>";
            echo "<td>" . $row["fname"] . "</td>";
            echo "<td>" . $row["fprice"] . "</td>";
            echo "<td>" . $row["category"] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "0 results";
    }
    ?>
</table>

<a href="addi.php"> <button class=btn>Add Item</button></a>

<a href="removei.php" ><button class=btn>Remove Item</button></a>
  
</section>

		<!-- <section id="3">
			<h2>Orders Management</h2>
			<table>
				<thead>
					<tr>
						<th>Order Number</th>
						<th>Items</th>
						<th>Total</th>
						<th>Status</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>#001</td>
						<td>Burger, Fries, Drink</td>
						<td>$10.00</td>
						<td>Pending</td>
					</tr>
					<tr>
						<td>#002</td>
						<td>Pizza, Drink</td>
						<td>$9.00</td>
						<td>Delivered</td>
					</tr>
					<tr>
						<td>#003</td>
						<td>Hot Dog, Drink</td>
						<td>$5.00</td>
						<td>Cancelled</td>
					</tr>
				</tbody>
			</table>
			<button>View Details</button>
		</section>-->
		<!-- <div id="satting"></div>
		<section>
			<h2>Settings</h2>
			<form>
				<label for="canteen-name">Canteen Name:</label>
				<input type="text" id="canteen-name" name="canteen-name" value="College Canteen">

				<label for="opening-hours">Opening Hours:</label>
				<input type="text" id="opening-hours" name="opening-hours" value="8am - 8pm"></inputtype>
				<label for="address">Address:</label>
				<textarea id="address" name="address">123 Main St, Anytown, USA</textarea>
	
				<label for="phone-number">Phone Number:</label>
				<input type="tel" id="phone-number" name="phone-number" value="555-1234">
	
				<button>Save Changes</button>
			</form>
		</section>-->
	</main>
	 <div id="footer">
        <div class="container text-center">
            <div class="col-md-6">
                <p>&copy; All rights reserved. Design by <a href="#" rel="nofollow">BackBanchers2.0</a></p>
            </div>
            <div class="col-md-6">
                <div class="social">
                    <ul>
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="assets/js/jquery.1.11.1.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/js/SmoothScroll.js"></script>
    <script type="text/javascript" src="assets/js/jqBootstrapValidation.js"></script>
    <script type="text/javascript" src="assets/js/contact_me.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>


	
</body>
</html>
	
