// JavaScript code for slideshow
var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}

// Automatic slideshow
var slideInterval = setInterval(function() {
  plusSlides(1);
}, 5000);


const addToCartButtons = document.querySelectorAll('.add-to-cart');

function addToCart(event) {
  const menuItem = event.target.closest('.menu-item');
  const itemName = menuItem.querySelector('h3').textContent;
  const itemPrice = 5.99; // Get the price
  const cartItem = {
    name: itemName,
    price: itemPrice,
    quantity: 1
  };

  // Check if the item is already in the cart
  const existingCartItem = findCartItem(cartItem.name);
  if (existingCartItem) {
    existingCartItem.quantity++;
  } else {
    cart.push(cartItem);
  }

  updateCart();
}

function findCartItem(itemName) {
  return cart.find(item => item.name === itemName);
}

function updateCart() {
  const cartCount = document.querySelector('.cart-count');
  const cartItems = document.querySelector('.cart-items');
  let total = 0;

  // Update the cart count
  let count = 0;
  for (let item of cart) {
    count += item.quantity;
    total += item.price * item.quantity;
  }
  cartCount.textContent = count;

  // Update the cart items
  cartItems.innerHTML = '';
  for (let item of cart) {
    const cartItem = document.createElement('div');
    cartItem.classList.add('cart-item');
    cartItem.innerHTML = `
      <span class="item-name">${item.name}</span>
      <span class="item-price">$${item.price.toFixed(2)}</span>
      <span class="item-quantity">${item.quantity}</span>
    `;
    cartItems.appendChild(cartItem);
  }

  // Update the total
  const cartTotal = document.querySelector('.cart-total');
  cartTotal.textContent = `$${total.toFixed(2)}`;
}

const cart = [];

for (let button of addToCartButtons) {
  button.addEventListener('click', addToCart);
}
