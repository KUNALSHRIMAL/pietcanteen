<?php

session_start();
include "config.php";

$username = $_POST['username'];
$password = $_POST['password'];

$q = " select * from registration where username = '$username' && password='$password' ";
$a="SELECT * from admin where username = '$username' && password='$password'";
$result = mysqli_query($con,$q);
$re=mysqli_query($con,$a);
$row = mysqli_num_rows($result);
$nom=mysqli_num_rows($re);

if ($nom==1 && $row==0) {
	$_SESSION['username'] = $username;
	header('location:admin/index.php');
}
else{
	if($row == 1){
		$_SESSION['username'] = $username;
		header('location:home.php');	
	}
	else{

		header('location:login.html');
	}
}
?>