<?php
    include "config.php";
    session_start();
    $username = $_SESSION['username'];
    $fname = $_POST['fname'];
    $fprice = $_POST['fprice'];
    $productid = $_POST['productid'];
    $cart = $_POST['cart'];
    $delete = $_POST['del'];
    $order = $_POST['order'];

    // Initialize total to 0
    $total = 0;

    if (isset($cart)) { 
        $result_username = mysqli_query($con,"select * from food where id = '$productid'") or die("failed to query database");
        $row_username = mysqli_fetch_array($result_username);
        if($row_username['id'] !== $productid) { 
            mysqli_query($con,"update food set cart = 'Y' where id= '$productid'") or die("failed to query database");
            echo '<script type ="text/javascript"> alert("Added to cart");window.history.go(-1);</script>';
            die();
        }
            mysqli_query($con,"update food set cart = 'Y' where id= '$productid'") or die("failed to query database");
            echo '<script type ="text/javascript"> alert("Added to cart");window.history.go(-1);</script>';

    die();

    }else if (isset($delete)) { 
        mysqli_query($con,"update food set cart = 'N' where id= '$productid'") or die("failed to query database");
        echo '<script type ="text/javascript"> alert("Product Successfully Removed.");window.history.go(-1);</script>';
    }else if (isset($order)) { 
        // Query database to retrieve items in cart for the logged-in user
        $result_cart = mysqli_query($con, "SELECT * FROM food WHERE cart = 'Y'");

        // Loop through results and add price of each item to total
        while ($row_cart = mysqli_fetch_array($result_cart)) {
            $total += $row_cart['fprice'];
        }

        // Save total to session variable
        $_SESSION['total'] = $total;

        header('location: checkout.php');
    }else {	
        header('location: login.html');
    }
?>